/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 14:46:55 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 17:11:56 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	ternary(int condition, int ret1, int ret2)
{
	if (condition)
		return (ret1);
	else
		return (ret2);
}

void	help_cast2(void)
{
	g_wall.foundVertWallHit = false;
	g_wall.vertWallHitX = 0;
	g_wall.vertWallHitY = 0;
	g_wall.xintercept = floor(g_nassim.x / TILE_SIZE) * TILE_SIZE;
	g_wall.xintercept += ternary((g_ray.isRayFacingRight), TILE_SIZE, 0);
	g_wall.yintercept = g_nassim.y + (g_wall.xintercept - g_nassim.x) * \
tan(g_ray.rayAngle);
	g_wall.xstep = TILE_SIZE;
	g_wall.xstep *= ternary((g_ray.isRayFacingLeft), -1, 1);
	g_wall.ystep = TILE_SIZE * tan(g_ray.rayAngle);
	g_wall.ystep *= ternary((g_ray.isRayFacingUp && g_wall.ystep > 0), -1, 1);
	g_wall.ystep *= ternary((g_ray.isRayFacingDown && g_wall.ystep < 0), -1, 1);
	g_wall.nextVertTouchX = g_wall.xintercept;
	g_wall.nextVertTouchY = g_wall.yintercept;
}

void	cast_ray(int col, float angle)
{
	ray_direction(angle);
	help_cast();
	castwhile(g_wall.nextHorzTouchX, g_wall.nextHorzTouchY);
	help_cast2();
	ray_direction(angle);
	castwhile2(g_wall.nextVertTouchX, g_wall.nextVertTouchY);
	help_norm();
	help_nor2(col);
	g_color.colorr = g_color.floor;
	dda(g_game_data.resolution_y / 2 + g_wall.wallStripHeight / 2, col, \
g_game_data.resolution_y, col);
	g_color.colorr = g_color.ceiling;
	dda(0, col, g_game_data.resolution_y / 2 - g_wall.wallStripHeight / 2, col);
	ft_empty_trash(angle, col);
}

int	main(int argc, char **argv)
{
	int	len;

	g_cub = (t_cub *)malloc(sizeof(t_cub));
	if (!g_cub)
		exit_game(6);
	ft_bzero(g_cub, sizeof(t_cub));
	len = ft_strlen(argv[1]) - 4;
	if (argc < 2 || argc > 3)
		exit_game(1);
	else if (!len)
		exit_game(2);
	else if (ft_strncmp(argv[1] + len, ".cub", 4))
		exit_game(3);
	if (argc == 3)
	{
		if (!ft_strncmp(argv[2], "--save", 6) && ft_strlen(argv[2]) == 6 )
			g_cub->save = 1;
		else
			exit_game(4);
	}
	init (argv);
	return (0);
}
