/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_readmap2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/15 18:32:56 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 18:19:41 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	free_tab(char **tab)
{
	int	i;

	i = -1;
	if (tab)
	{
		while (tab[++i])
			free(tab[i]);
		free(tab);
	}
}

void	handle_texture(char *line, int i)
{
	while (ft_isspace(line[i]))
		i++;
	norm_texture(line, i);
}

void	split_tab(char *line)
{
	char	**tab;
	int		i;

	i = 0;
	tab = ft_split(line, ' ');
	if (ft_tablen(tab))
	{
		if (!is_belogn("RNSWCFE10 ", *tab))
		{
			exit_game(6);
		}
		while (ft_isspace(line[i]))
			i++;
		handle_texture(line, i);
		if (!ft_strncmp(tab[0], "R", 1))
			ressolution(&g_game_data.resolution_x, \
&g_game_data.resolution_y, tab);
		norm_file(line, i);
		check_identifier(tab[0]);
	}
	free_tab(tab);
}

void	ressolution(int	*x, int	*y, char **tab)
{
	int	i;
	int	len;

	i = -1;
	len = 0;
	set_resolution(tab, i, len);
	i = -1;
	len = ft_strlen(tab[2]);
	while (++i < len)
		if (!ft_isdigit(tab[2][i]))
			exit_game(23);
	*x = ft_atoi(tab[1]);
	*y = ft_atoi(tab[2]);
	if (*x > 2561 || *x < 0 )
		*x = 2560;
	if (*y > 1440 || *y < 0 )
		*y = 1440;
}

void	save_path(char **path, char **text, char **tab, int *i)
{
	char	*ext;

	*i += 1;
	if (ft_strlen(tab[0]) >= 3)
		exit_game(24);
	*path = ft_strdup(tab[0]);
	*text = ft_strdup(tab[1]);
	if (*text == NULL)
		exit_game(6);
	ext = ft_strrchr(tab[1], '.');
	if (ft_strncmp(ext + 1, "xpm", 3) != 0 || ft_strlen(ext + 1) > 3)
		exit_game(10);
}
