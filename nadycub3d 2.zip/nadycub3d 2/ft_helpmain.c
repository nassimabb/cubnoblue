/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_helpmain.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 14:43:42 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 17:22:45 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	init(char **argv)
{
	g_game_data.big_colon = 0;
	g_game_data.big_line = 0;
	init_identifiers();
	ft_readmap(argv[1]);
	g_mlx = mlx_init();
	g_mlx_win = mlx_new_window(g_mlx, g_game_data.resolution_x, \
g_game_data.resolution_y, "CUb3d");
	g_img.img = NULL;
	g_map = fill_map();
	get_player_pos();
	check_map();
	init_struct();
	init_textures();
	init_sprites();
	mlx_hook(g_mlx_win, 2, 0, key_press_hook, "lll");
	mlx_hook(g_mlx_win, 3, 0, key_release_hook, "lll");
	mlx_loop_hook(g_mlx, &ft_update, "");
	mlx_hook(g_mlx_win, 17, 1L << 5, exit_game, "lll");
	mlx_loop(g_mlx);
}
